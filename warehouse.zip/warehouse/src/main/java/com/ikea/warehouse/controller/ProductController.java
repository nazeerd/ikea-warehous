package com.ikea.warehouse.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ikea.warehouse.pojo.Order;
import com.ikea.warehouse.pojo.Product;
import com.ikea.warehouse.service.ProductService;

import jakarta.websocket.server.PathParam;

@RestController("/products")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping("/")
	public List<String> fetchProducts() {
		return productService.fetchProducts();
	}
	@GetMapping("/{name}")
	public Product fetchProduct(@PathParam("name") String name) {
		return productService.fetchProducts(name);
	}
	
	@PostMapping("/order")
	public String order(@RequestBody List<Order> orders) {
		return productService.placeAnOrder(orders);
	}
}
