package com.ikea.warehouse.dao;

import java.util.List;

import com.ikea.warehouse.pojo.Product;

public interface ProductDao {
	public Product getByName(String name);
	public List<Product> getProducts();
}
