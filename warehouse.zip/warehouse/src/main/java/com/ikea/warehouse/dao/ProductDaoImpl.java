package com.ikea.warehouse.dao;

import java.util.List;

import com.ikea.warehouse.pojo.Product;

public class ProductDaoImpl implements ProductDao{

	@Override
	public Product getByName(String name) {
		// will return output of below query
		// select * from products where name=<name>;
		return null;
	}

	@Override
	public List<Product> getProducts() {
		// will return output of below query
		// select * from products;
		return null;
	}

}
