package com.ikea.warehouse.service;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.print.attribute.HashAttributeSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ikea.warehouse.dao.InventoryDao;
import com.ikea.warehouse.dao.ProductDao;
import com.ikea.warehouse.pojo.Inventory;
import com.ikea.warehouse.pojo.Order;
import com.ikea.warehouse.pojo.Product;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private InventoryDao inventoryDao;

	@Override
	public List<String> fetchProducts() {
		// TODO Auto-generated method stub
		return productDao.getProducts().stream().map(product->product.getName()).collect(Collectors.toList());
	}

	@Override
	public Product fetchProducts(String name) {
	 List<Inventory> availableInventories =	inventoryDao.fetchInventory();
	 Product desireProdct = productDao.getByName(name);
	 Map<String,String > productAricleCountMap = new HashMap<>();
	 desireProdct.getArticales().stream().forEach(article->{
		 int requiredArticles = Integer.valueOf(article.getAmountOf());
		 int availableArticles = Integer.valueOf(availableInventories.stream().filter(inv->article.getAricleId().equals(inv.getArtId())).map(inv->inv.getStock()).findFirst().orElse(null));
		 if(availableArticles == 0) 
			 return;
		 int makableProcutCount = availableArticles/requiredArticles;
		 if(makableProcutCount==0)
			 return;
		 productAricleCountMap.put(article.getAricleId(), String.valueOf(makableProcutCount));
		 
	 });
	 if(desireProdct.getArticales().size() != productAricleCountMap.size())
		 return new Product();
	 Map.Entry<String,String> makableProducts = productAricleCountMap.entrySet().stream()
     .sorted(Map.Entry.comparingByValue())
     .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
             (oldValue, newValue) -> oldValue, LinkedHashMap::new)).entrySet().iterator().next();
	 desireProdct.setStock(Integer.parseInt(makableProducts.getValue()));
		return desireProdct;
	}

	@Override
	public String placeAnOrder(List<Order> orders) {
		orders.stream().forEach(item->{
			this.updateInventory(item);
		});
		return "Ordered Successfully";
	}
	
	 private void updateInventory(Order item ) {
		Product product = item.getProduct();
		int requiredQuantity = item.getQuantity();
		product.getArticales().forEach(article->{
			String totalArticleCounts = String.valueOf( requiredQuantity * Integer.parseInt(article.getAmountOf()));
			inventoryDao.updateInventory(article.getAricleId(), totalArticleCounts);
		});
	}

}
