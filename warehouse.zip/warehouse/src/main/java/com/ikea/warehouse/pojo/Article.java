package com.ikea.warehouse.pojo;

public class Article {
	private String aricleId;
	private String amountOf;
	public String getAricleId() {
		return aricleId;
	}
	public void setAricleId(String aricleId) {
		this.aricleId = aricleId;
	}
	public String getAmountOf() {
		return amountOf;
	}
	public void setAmountOf(String amountOf) {
		this.amountOf = amountOf;
	}
	
}
