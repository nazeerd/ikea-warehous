package com.ikea.warehouse.service;

import java.util.List;

import com.ikea.warehouse.pojo.Order;
import com.ikea.warehouse.pojo.Product;

public interface ProductService {
public List<String> fetchProducts();
public Product fetchProducts(String name);
public String placeAnOrder(List<Order> orders);
}
