package com.ikea.warehouse.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.ikea.warehouse.pojo.Inventory;

@Repository
public class InventoryDaoImpl implements InventoryDao{

	@Override
	public List<Inventory> fetchInventory() {
		// TODO Auto-generated method stub
		List<Inventory> list = null;
		//select * from Inventory;
		return list;
	}

	@Override
	public int updateInventory(String artId, String consumedCount) {
		//update Inventory stock=( select stock from Inventory where art_id=<artId>) where art_id=<artId>;
		//using above query will update 
		return 0;
	}

}
