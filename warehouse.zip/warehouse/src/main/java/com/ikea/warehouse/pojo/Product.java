package com.ikea.warehouse.pojo;

import java.util.List;
public class Product {
	private String name;
	private List<Article> articales;
	// This will be computed in productServiceImpl.fetchProducts(String name)
	private int stock;
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Article> getArticales() {
		return articales;
	}
	public void setArticales(List<Article> articales) {
		this.articales = articales;
	}

}
