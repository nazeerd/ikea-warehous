package com.ikea.warehouse.dao;

import java.util.List;

import com.ikea.warehouse.pojo.Inventory;

public interface InventoryDao {
	public List<Inventory> fetchInventory();
	public int updateInventory(String artId, String consumedCount);
}
